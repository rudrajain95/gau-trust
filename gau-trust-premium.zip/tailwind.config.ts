import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eff8ff",
          100: "#dff1ff",
          200: "#b8e3ff",
          300: "#7ecbff",
          400: "#3ab0ff",
          500: "#1493ff",
          600: "#0b75db",
          700: "#0a5cac",
          800: "#0d4c8b",
          900: "#0f3f73"
        },
        ink: {
          50:"#f8fafc",
          100:"#f1f5f9",
          200:"#e2e8f0",
          300:"#cbd5e1",
          400:"#94a3b8",
          500:"#64748b",
          600:"#475569",
          700:"#334155",
          800:"#1f2937",
          900:"#0f172a"
        }
      },
      boxShadow: {
        soft: "0 10px 30px rgba(2, 6, 23, .08)"
      }
    },
  },
  plugins: [],
} satisfies Config;
