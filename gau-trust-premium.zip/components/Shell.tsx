import Link from "next/link";
import { ReactNode } from "react";
import { Role } from "@prisma/client";

export function Shell({
  title,
  subtitle,
  children,
  user,
  nav,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  user?: { name: string | null; phone: string; role: Role };
  nav?: { href: string; label: string }[];
}) {
  return (
    <div className="min-h-screen bg-ink-50">
      <header className="sticky top-0 z-10 border-b border-ink-200/70 bg-white/80 backdrop-blur">
        <div className="container-pad flex items-center justify-between py-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-2xl bg-brand-600 text-white grid place-items-center font-black">G</div>
              <div className="leading-tight">
                <div className="text-sm font-black tracking-tight">{title}</div>
                {subtitle ? <div className="text-xs text-ink-500">{subtitle}</div> : null}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {user ? (
              <span className="badge">
                {user.name ?? "User"} • {user.phone} • {user.role}
              </span>
            ) : (
              <Link className="btn-secondary" href="/auth">Login</Link>
            )}
            {user ? <Link className="btn-secondary" href="/api/auth/logout">Logout</Link> : null}
          </div>
        </div>

        {nav?.length ? (
          <div className="border-t border-ink-200/60 bg-white">
            <div className="container-pad flex gap-2 py-2 overflow-x-auto">
              {nav.map((n) => (
                <Link key={n.href} href={n.href} className="btn-secondary whitespace-nowrap">
                  {n.label}
                </Link>
              ))}
            </div>
          </div>
        ) : null}
      </header>

      <main className="container-pad py-6">{children}</main>
    </div>
  );
}
