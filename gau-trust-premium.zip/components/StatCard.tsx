export function StatCard({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="card p-4">
      <div className="text-xs font-semibold text-ink-500">{label}</div>
      <div className="mt-1 text-2xl font-black tracking-tight">{value}</div>
      {hint ? <div className="mt-2 text-xs text-ink-500">{hint}</div> : null}
    </div>
  );
}
