import { Shell } from "@/components/Shell";
import { getSession } from "@/lib/auth";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  return (
    <Shell
      title="Gau Trust"
      subtitle="Admin"
      user={session?.user ? { name: session.user.name, phone: session.user.phone, role: session.user.role } : undefined}
      nav={[
        { href: "/admin", label: "Overview" },
        { href: "/admin/shops", label: "Shops" },
        { href: "/admin/refunds", label: "Refunds" },
        { href: "/admin/settings", label: "Settings" },
      ]}
    >
      {children}
    </Shell>
  );
}
