import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/auth";

export default async function AdminShops() {
  const auth = await requireRole(["ADMIN"]);
  if (!auth.ok) return <div className="card p-6">Admin only.</div>;

  const shops = await prisma.shop.findMany({ include: { owner: true }, orderBy: { createdAt: "desc" } });

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Shops</div>
        <div className="text-sm text-ink-600">Approve shops and set commission percent (default 8%).</div>
      </div>

      <div className="grid gap-3">
        {shops.map(s => (
          <form key={s.id} className="card p-5 flex flex-wrap items-center justify-between gap-3" action="/api/admin/shops/update" method="post">
            <input type="hidden" name="shopId" value={s.id} />
            <div>
              <div className="font-black">{s.name} {s.approved ? <span className="badge ml-2">Approved</span> : <span className="badge ml-2">Pending</span>}</div>
              <div className="text-xs text-ink-500">Owner: {s.owner.phone}</div>
            </div>
            <div className="flex items-center gap-2">
              <input className="input w-24" name="commissionPercent" type="number" min="0" max="30" defaultValue={s.commissionPercent} />
              <select className="input w-36" name="approved" defaultValue={String(s.approved)}>
                <option value="true">Approve</option>
                <option value="false">Reject</option>
              </select>
              <button className="btn-primary" type="submit">Save</button>
            </div>
          </form>
        ))}
      </div>
    </div>
  );
}
