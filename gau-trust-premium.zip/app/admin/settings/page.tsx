import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function AdminSettings() {
  const auth = await requireRole(["ADMIN"]);
  if (!auth.ok) return <div className="card p-6">Admin only.</div>;

  const s = await prisma.settings.upsert({ where: { id: "singleton" }, update: {}, create: { id: "singleton" } });

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Settings</div>
        <div className="text-sm text-ink-600">Configure delivery fees, support contact, etc.</div>
      </div>

      <form className="card p-5 space-y-4" action="/api/admin/settings/update" method="post">
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <label className="text-sm font-semibold">Delivery Fee 0–3km (₹)</label>
            <input className="input mt-1" name="deliveryFee0to3" type="number" defaultValue={s.deliveryFee0to3} />
          </div>
          <div>
            <label className="text-sm font-semibold">Delivery Fee 3–6km (₹)</label>
            <input className="input mt-1" name="deliveryFee3to6" type="number" defaultValue={s.deliveryFee3to6} />
          </div>
          <div>
            <label className="text-sm font-semibold">Subscription Price (₹)</label>
            <input className="input mt-1" name="subscriptionPrice" type="number" defaultValue={s.subscriptionPrice} />
          </div>
          <div>
            <label className="text-sm font-semibold">Support Contact</label>
            <input className="input mt-1" name="supportContact" defaultValue={s.supportContact} />
          </div>
        </div>
        <button className="btn-primary w-full" type="submit">Save Settings</button>
      </form>
    </div>
  );
}
