import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function AdminRefunds() {
  const auth = await requireRole(["ADMIN"]);
  if (!auth.ok) return <div className="card p-6">Admin only.</div>;

  const refunds = await prisma.refundRequest.findMany({
    orderBy: { createdAt: "desc" },
    take: 50,
    include: { order: true, user: true, photo: true, video: true },
  });

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Refund Requests</div>
        <div className="text-sm text-ink-600">Approve within 24–48h (rule).</div>
      </div>

      <div className="grid gap-3">
        {refunds.map(r => (
          <form key={r.id} className="card p-5 space-y-3" action="/api/admin/refunds/update" method="post">
            <input type="hidden" name="refundId" value={r.id} />
            <div className="flex items-start justify-between">
              <div>
                <div className="font-black">Order #{r.orderId.slice(-6)} • {r.user.phone}</div>
                <div className="text-xs text-ink-500">{r.createdAt.toLocaleString()} • Status: {r.status}</div>
              </div>
              <span className="badge">{r.status}</span>
            </div>
            <div className="text-sm text-ink-700">Reason: {r.reason}</div>
            <div className="text-xs text-ink-500">Photo: {r.photo.path} {r.video ? `• Video: ${r.video.path}` : ""}</div>

            <div className="flex flex-wrap items-center gap-2">
              <select className="input w-40" name="status" defaultValue={r.status}>
                <option value="PENDING">PENDING</option>
                <option value="APPROVED">APPROVE</option>
                <option value="REJECTED">REJECT</option>
              </select>
              <input className="input flex-1 min-w-52" name="adminNote" defaultValue={r.adminNote ?? ""} placeholder="Admin note (optional)" />
              <button className="btn-primary" type="submit">Update</button>
            </div>
          </form>
        ))}
      </div>
    </div>
  );
}
