import Link from "next/link";
import { requireRole } from "@/lib/auth";

export default async function AdminHome() {
  const auth = await requireRole(["ADMIN"]);
  if (!auth.ok) return <div className="card p-6">Admin only. Please login as ADMIN.</div>;

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Admin Dashboard</div>
        <div className="text-sm text-ink-600">Manage shops, refunds, and settings (demo).</div>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <Link className="card p-5 hover:ring-2 hover:ring-brand-200" href="/admin/shops">
          <div className="font-black">Shops</div>
          <div className="text-sm text-ink-600">Approve + commission</div>
        </Link>
        <Link className="card p-5 hover:ring-2 hover:ring-brand-200" href="/admin/refunds">
          <div className="font-black">Refunds</div>
          <div className="text-sm text-ink-600">Approve within 24–48h</div>
        </Link>
        <Link className="card p-5 hover:ring-2 hover:ring-brand-200" href="/admin/settings">
          <div className="font-black">Settings</div>
          <div className="text-sm text-ink-600">Delivery fees, support contact</div>
        </Link>
      </div>
    </div>
  );
}
