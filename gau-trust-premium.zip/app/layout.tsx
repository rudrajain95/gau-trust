import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Gau Trust",
  description: "Dairy marketplace + subscription",
  manifest: "/manifest.webmanifest",
  themeColor: "#1493ff",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
