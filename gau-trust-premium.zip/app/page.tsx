import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";

export default async function Page() {
  const session = await getSession();
  if (!session) redirect("/auth");
  // Route by role
  const role = session.user.role;
  if (role === "ADMIN") redirect("/admin");
  if (role === "SHOP_OWNER") redirect("/shop");
  if (role === "DELIVERY") redirect("/delivery");
  redirect("/customer");
}
