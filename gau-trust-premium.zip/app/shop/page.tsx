import { requireRole } from "@/lib/auth";
import Link from "next/link";

export default async function ShopOwnerHome() {
  const auth = await requireRole(["SHOP_OWNER"]);
  if (!auth.ok) return <div className="card p-6">Shop Owner only. Login with SHOP_OWNER demo.</div>;

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Shop Owner Portal</div>
        <div className="text-sm text-ink-600">Manage products, accept orders (demo scaffolding).</div>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <Link className="card p-5 hover:ring-2 hover:ring-brand-200" href="/shop/products">
          <div className="font-black">Products</div>
          <div className="text-sm text-ink-600">Price, stock, expiry</div>
        </Link>
        <Link className="card p-5 hover:ring-2 hover:ring-brand-200" href="/shop/orders">
          <div className="font-black">Orders</div>
          <div className="text-sm text-ink-600">Accept / Reject</div>
        </Link>
      </div>
    </div>
  );
}
