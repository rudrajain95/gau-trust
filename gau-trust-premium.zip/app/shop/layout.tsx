import { Shell } from "@/components/Shell";
import { getSession } from "@/lib/auth";

export default async function ShopLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  return (
    <Shell
      title="Gau Trust"
      subtitle="Shop Owner"
      user={session?.user ? { name: session.user.name, phone: session.user.phone, role: session.user.role } : undefined}
      nav={[
        { href: "/shop", label: "Overview" },
        { href: "/shop/products", label: "Products" },
        { href: "/shop/orders", label: "Orders" },
      ]}
    >
      {children}
    </Shell>
  );
}
