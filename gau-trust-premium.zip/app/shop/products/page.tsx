import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function ShopProducts() {
  const auth = await requireRole(["SHOP_OWNER"]);
  if (!auth.ok) return <div className="card p-6">Shop Owner only.</div>;

  const shop = await prisma.shop.findFirst({ where: { ownerId: auth.session!.user.id } });
  if (!shop) return <div className="card p-6">No shop assigned to this owner in seed.</div>;

  const products = await prisma.product.findMany({ where: { shopId: shop.id }, orderBy: { name: "asc" } });

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Products</div>
        <div className="text-sm text-ink-600">Update stock and price (demo).</div>
      </div>

      <div className="grid gap-3">
        {products.map(p => (
          <form key={p.id} className="card p-5 flex flex-wrap items-center justify-between gap-3" action="/api/shop/products/update" method="post">
            <input type="hidden" name="productId" value={p.id} />
            <div>
              <div className="font-black">{p.name}</div>
              <div className="text-xs text-ink-500">{p.variant ?? p.category}</div>
            </div>
            <div className="flex items-center gap-2">
              <input className="input w-24" name="price" type="number" defaultValue={p.price} />
              <input className="input w-24" name="stock" type="number" defaultValue={p.stock} />
              <button className="btn-primary" type="submit">Save</button>
            </div>
          </form>
        ))}
      </div>
    </div>
  );
}
