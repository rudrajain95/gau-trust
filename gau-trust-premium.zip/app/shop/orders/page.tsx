import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function ShopOrders() {
  const auth = await requireRole(["SHOP_OWNER"]);
  if (!auth.ok) return <div className="card p-6">Shop Owner only.</div>;

  const shop = await prisma.shop.findFirst({ where: { ownerId: auth.session!.user.id } });
  if (!shop) return <div className="card p-6">No shop assigned.</div>;

  const orders = await prisma.order.findMany({
    where: { shopId: shop.id },
    orderBy: { createdAt: "desc" },
    take: 20,
    include: { user: true },
  });

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Orders</div>
        <div className="text-sm text-ink-600">Accept / Reject / Packed / Ready (demo).</div>
      </div>

      <div className="grid gap-3">
        {orders.map(o => (
          <form key={o.id} className="card p-5 flex flex-wrap items-center justify-between gap-3" action="/api/shop/orders/update" method="post">
            <input type="hidden" name="orderId" value={o.id} />
            <div>
              <div className="font-black">#{o.id.slice(-6)} • {o.user.phone}</div>
              <div className="text-xs text-ink-500">{o.createdAt.toLocaleString()} • Total ₹{o.total}</div>
            </div>
            <div className="flex items-center gap-2">
              <select className="input w-48" name="status" defaultValue={o.status}>
                <option value="ACCEPTED">ACCEPTED</option>
                <option value="REJECTED">REJECTED</option>
                <option value="PACKED">PACKED</option>
                <option value="OUT_FOR_DELIVERY">OUT_FOR_DELIVERY</option>
              </select>
              <button className="btn-primary" type="submit">Update</button>
            </div>
          </form>
        ))}
      </div>
    </div>
  );
}
