import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/rules";
import Link from "next/link";

export default async function WalletPage() {
  const session = await getSession();
  if (!session) {
    return <div className="card p-6 text-sm text-ink-600">Please <Link className="link" href="/auth">login</Link> to use Wallet.</div>;
  }
  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  const settings = await getSettings();
  const now = new Date();
  const subActive = user?.subscriptionEndsAt ? user.subscriptionEndsAt > now : false;

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Wallet</div>
        <div className="text-sm text-ink-600">UPI, Wallet, QR, COD rules apply at checkout (demo).</div>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <div className="card p-5">
          <div className="text-xs font-semibold text-ink-500">Wallet Balance</div>
          <div className="mt-1 text-2xl font-black">₹{user?.walletBalance ?? 0}</div>
          <div className="mt-3 text-xs text-ink-500">Topup flow can be added with payment gateway.</div>
        </div>
        <div className="card p-5">
          <div className="text-xs font-semibold text-ink-500">Steel Deposit</div>
          <div className="mt-1 text-2xl font-black">₹0</div>
          <div className="mt-3 text-xs text-ink-500">Placeholder module.</div>
        </div>
        <div className="card p-5">
          <div className="text-xs font-semibold text-ink-500">Coins</div>
          <div className="mt-1 text-2xl font-black">{user?.coinBalance ?? 0}</div>
          <div className="mt-3 text-xs text-ink-500">Redeem at 500 coins (subscribers only).</div>
        </div>
      </div>

      <div className="card p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="font-black">Subscription</div>
            <div className="text-sm text-ink-600">₹{settings.subscriptionPrice}/month • Free delivery 6AM–9PM • Refunds • Coins</div>
          </div>
          <form action="/api/subscription/buy" method="post">
            <button className="btn-primary" type="submit" disabled={subActive}>
              {subActive ? "Active" : "Buy ₹199"}
            </button>
          </form>
        </div>
        {user?.subscriptionEndsAt ? <div className="mt-2 text-xs text-ink-500">Ends at: {user.subscriptionEndsAt.toLocaleString()}</div> : null}
      </div>

      <div className="card p-5">
        <div className="font-black">Redeem</div>
        <div className="text-sm text-ink-600">At 500 coins, redeem one reward.</div>
        <form className="mt-3 flex flex-wrap gap-2" action="/api/coins/redeem" method="post">
          <select className="input w-full md:w-auto" name="reward" defaultValue="₹200 Voucher">
            <option>₹200 Voucher</option>
            <option>Ghee Can</option>
            <option>Paneer Pack</option>
          </select>
          <button className="btn-primary" type="submit">Redeem (500 coins)</button>
        </form>
      </div>
    </div>
  );
}
