import { getSettings } from "@/lib/rules";

export default async function SupportPage() {
  const s = await getSettings();
  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Customer Care</div>
        <div className="text-sm text-ink-600">Support contact is configurable by Admin.</div>
      </div>

      <div className="card p-6">
        <div className="text-sm text-ink-600">Support Contact</div>
        <div className="mt-1 text-2xl font-black">{s.supportContact}</div>
        <div className="mt-4 flex gap-2">
          <button
            className="btn-primary"
            onClick={() => navigator.clipboard.writeText(s.supportContact)}
          >
            Copy
          </button>
          <div className="text-xs text-ink-500 self-center">Call button can be enabled later.</div>
        </div>
      </div>
    </div>
  );
}
