import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function MarketplacePage() {
  const shops = await prisma.shop.findMany({
    where: { approved: true },
    include: { products: { where: { active: true }, take: 50 } },
    take: 10,
  });

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Marketplace</div>
        <div className="text-sm text-ink-600">Choose a shop and add dairy items to cart (demo checkout).</div>
      </div>

      {shops.length === 0 ? (
        <div className="card p-6 text-sm text-ink-600">No shops approved yet. Admin can approve shops from Admin dashboard.</div>
      ) : null}

      <div className="grid gap-4 md:grid-cols-2">
        {shops.map((shop) => (
          <div key={shop.id} className="card p-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-base font-black">{shop.name}</div>
                <div className="text-xs text-ink-500">Commission: {shop.commissionPercent}%</div>
              </div>
              <Link className="btn-primary" href={`/customer/marketplace/shop/${shop.id}`}>Open</Link>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {shop.products.slice(0, 6).map((p) => (
                <div key={p.id} className="rounded-2xl border border-ink-200 bg-ink-50 p-3">
                  <div className="text-sm font-bold">{p.name}</div>
                  <div className="text-xs text-ink-500">{p.variant ?? p.category}</div>
                  <div className="mt-2 text-sm font-black">₹{p.price}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
