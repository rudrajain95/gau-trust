import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";

export default async function ShopPage({ params }: { params: { shopId: string } }) {
  const shop = await prisma.shop.findUnique({
    where: { id: params.shopId },
    include: { products: { where: { active: true }, orderBy: { category: "asc" } } },
  });
  if (!shop) redirect("/customer/marketplace");

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">{shop.name}</div>
        <div className="text-sm text-ink-600">Add items and checkout (demo).</div>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {shop.products.map((p) => (
          <form key={p.id} className="card p-5 flex items-center justify-between gap-3" action="/api/cart/add" method="post">
            <input type="hidden" name="productId" value={p.id} />
            <input type="hidden" name="shopId" value={shop.id} />
            <div>
              <div className="font-black">{p.name}</div>
              <div className="text-xs text-ink-500">{p.variant ?? p.category} • Stock: {p.stock}</div>
              <div className="mt-1 font-black">₹{p.price}</div>
            </div>
            <div className="flex items-center gap-2">
              <input className="input w-20" name="qty" type="number" min="1" defaultValue="1" />
              <button className="btn-primary" type="submit">Add</button>
            </div>
          </form>
        ))}
      </div>

      <form className="card p-5" action="/api/checkout/demo" method="post">
        <input type="hidden" name="shopId" value={shop.id} />
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="font-black">Checkout</div>
            <div className="text-xs text-ink-500">Demo checkout applies delivery rules.</div>
          </div>
          <button className="btn-primary" type="submit">Place Demo Order</button>
        </div>
      </form>
    </div>
  );
}
