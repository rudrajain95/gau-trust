import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { getSession } from "@/lib/auth";

export default async function OrderDetail({ params }: { params: { orderId: string } }) {
  const session = await getSession();
  const order = await prisma.order.findUnique({
    where: { id: params.orderId },
    include: { items: { include: { product: true } }, shop: true, tracking: { orderBy: { createdAt: "asc" } } , refundRequest: true},
  });

  if (!order) return <div className="card p-6">Order not found.</div>;
  if (!session || session.user.id !== order.userId) return <div className="card p-6">Unauthorized.</div>;

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="flex items-start justify-between">
          <div>
            <div className="text-lg font-black tracking-tight">{order.shop.name}</div>
            <div className="text-sm text-ink-600">Order #{order.id.slice(-6)} • {order.createdAt.toLocaleString()}</div>
          </div>
          <span className="badge">{order.status}</span>
        </div>
        <div className="mt-3 text-sm font-semibold">Total: ₹{order.total} (Delivery ₹{order.deliveryFee})</div>
        <div className="mt-2 text-xs text-ink-500">Demo map: we store tracking events; delivery agent can add location events.</div>
      </div>

      <div className="card p-5">
        <div className="font-black">Items</div>
        <div className="mt-3 grid gap-2">
          {order.items.map(i => (
            <div key={i.id} className="flex items-center justify-between rounded-xl border border-ink-200 bg-ink-50 p-3">
              <div>
                <div className="font-semibold">{i.product.name}</div>
                <div className="text-xs text-ink-500">{i.product.variant ?? i.product.category}</div>
              </div>
              <div className="text-sm font-black">₹{i.lineTotal}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="card p-5">
        <div className="font-black">Status Timeline</div>
        <div className="mt-3 grid gap-2">
          {order.tracking.map(t => (
            <div key={t.id} className="rounded-xl border border-ink-200 bg-white p-3">
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold">{t.type}</div>
                <div className="text-xs text-ink-500">{t.createdAt.toLocaleString()}</div>
              </div>
              <div className="mt-1 text-xs text-ink-500">
                {t.latitude && t.longitude ? `Location: ${t.latitude}, ${t.longitude}` : "No location"}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <Link className="btn-secondary" href={`/customer/refund?orderId=${order.id}`}>Request Refund</Link>
        </div>
      </div>

      {order.refundRequest ? (
        <div className="card p-5">
          <div className="font-black">Refund Request</div>
          <div className="mt-2 text-sm text-ink-600">Status: {order.refundRequest.status}</div>
        </div>
      ) : null}
    </div>
  );
}
