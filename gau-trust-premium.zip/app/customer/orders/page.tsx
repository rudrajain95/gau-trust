import Link from "next/link";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function OrdersPage() {
  const session = await getSession();
  if (!session) {
    return <div className="card p-6 text-sm text-ink-600">Please <Link className="link" href="/auth">login</Link> to see your orders.</div>;
  }

  const orders = await prisma.order.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: "desc" },
    take: 20,
    include: { shop: true },
  });

  return (
    <div className="space-y-3">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Your Orders</div>
        <div className="text-sm text-ink-600">Track status timeline + demo map events.</div>
      </div>

      {orders.length === 0 ? (
        <div className="card p-6 text-sm text-ink-600">No orders yet. Go to Marketplace and place a demo order.</div>
      ) : null}

      <div className="grid gap-3">
        {orders.map(o => (
          <Link key={o.id} href={`/customer/orders/${o.id}`} className="card p-5 hover:ring-2 hover:ring-brand-200 transition">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-black">{o.shop.name}</div>
                <div className="text-xs text-ink-500">{o.createdAt.toLocaleString()}</div>
              </div>
              <span className="badge">{o.status}</span>
            </div>
            <div className="mt-3 text-sm font-semibold">Total: ₹{o.total} • Delivery: ₹{o.deliveryFee} • {o.distanceKm ?? 0} km</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
