import { Shell } from "@/components/Shell";
import { getSession } from "@/lib/auth";
import { getSettings } from "@/lib/rules";

export default async function CustomerLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  const settings = await getSettings();
  return (
    <Shell
      title="Gau Trust"
      subtitle="Customer App"
      user={session?.user ? { name: session.user.name, phone: session.user.phone, role: session.user.role } : undefined}
      nav={[
        { href: "/customer", label: "Home" },
        { href: "/customer/marketplace", label: "Marketplace" },
        { href: "/customer/orders", label: "Orders" },
        { href: "/customer/wallet", label: "Wallet" },
        { href: "/customer/profile", label: "Profile" },
        { href: "/customer/support", label: "Customer Care" },
      ]}
    >
      <div className="mb-4 card p-3 flex items-center justify-between">
        <div className="text-sm text-ink-700">
          Support: <span className="font-bold">{settings.supportContact}</span>
        </div>
        <div className="text-xs text-ink-500">Configurable in Admin → Settings</div>
      </div>
      {children}
    </Shell>
  );
}
