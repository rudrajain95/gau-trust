import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { StatCard } from "@/components/StatCard";

export default async function CustomerHome() {
  const session = await getSession();
  const user = session?.user ? await prisma.user.findUnique({ where: { id: session.user.id } }) : null;

  const now = new Date();
  const trialLeftDays = user?.trialEndsAt ? Math.max(0, Math.ceil((user.trialEndsAt.getTime() - now.getTime()) / (1000*60*60*24))) : 0;
  const subActive = user?.subscriptionEndsAt ? user.subscriptionEndsAt > now : false;

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-sm text-ink-600">Welcome</div>
        <div className="text-2xl font-black tracking-tight">{user?.name ?? "Guest"}</div>
        <div className="mt-2 flex flex-wrap gap-2">
          <span className="badge">Trial: {trialLeftDays} days</span>
          <span className="badge">Subscription: {subActive ? "Active" : "Not active"}</span>
          <span className="badge">Coins: {user?.coinBalance ?? 0}</span>
        </div>
        <div className="mt-4 text-sm text-ink-600">
          Subscribers get free delivery 6AM–9PM, refunds, coins, and morning fresh milk.
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <StatCard label="Wallet Balance" value={`₹${user?.walletBalance ?? 0}`} hint="Use Wallet at checkout" />
        <StatCard label="Coin Progress" value={`${user?.coinBalance ?? 0} / 500`} hint="Redeem at 500 coins" />
        <StatCard label="Subscription" value={subActive ? "Active" : "₹199 / month"} hint="Buy subscription on Wallet page" />
      </div>

      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Daily Farm Video</div>
        <div className="mt-1 text-sm text-ink-600">Subscribers only (demo shows latest title in Orders page later).</div>
        <div className="mt-4 rounded-2xl bg-ink-100 p-4 text-sm text-ink-700">
          Admin uploads a daily video; subscribers automatically get a notification entry.
        </div>
      </div>
    </div>
  );
}
