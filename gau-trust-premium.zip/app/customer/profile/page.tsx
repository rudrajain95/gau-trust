import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function ProfilePage() {
  const session = await getSession();
  if (!session) return <div className="card p-6 text-sm text-ink-600">Please <Link className="link" href="/auth">login</Link>.</div>;

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: { addresses: { take: 1 } },
  });

  const addr = user?.addresses?.[0];

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Profile</div>
        <div className="text-sm text-ink-600">Update your details (saved to database).</div>
      </div>

      <form className="card p-5 space-y-4" action="/api/profile/update" method="post">
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <label className="text-sm font-semibold">Name</label>
            <input className="input mt-1" name="name" defaultValue={user?.name ?? ""} placeholder="Your name" />
          </div>
          <div>
            <label className="text-sm font-semibold">Email</label>
            <input className="input mt-1" name="email" defaultValue={user?.email ?? ""} placeholder="you@example.com" />
          </div>
          <div>
            <label className="text-sm font-semibold">Mobile</label>
            <input className="input mt-1" name="phone" defaultValue={user?.phone ?? ""} disabled />
            <div className="mt-1 text-xs text-ink-500">Phone is your login ID.</div>
          </div>
          <div>
            <label className="text-sm font-semibold">Notes</label>
            <input className="input mt-1" name="notes" defaultValue={user?.notes ?? ""} placeholder="Delivery notes, gate, landmark…" />
          </div>
        </div>

        <div className="border-t border-ink-200 pt-4">
          <div className="font-black">Address</div>
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            <div>
              <label className="text-sm font-semibold">Line 1</label>
              <input className="input mt-1" name="line1" defaultValue={addr?.line1 ?? ""} placeholder="House/Street" />
            </div>
            <div>
              <label className="text-sm font-semibold">Line 2</label>
              <input className="input mt-1" name="line2" defaultValue={addr?.line2 ?? ""} placeholder="Landmark (optional)" />
            </div>
            <div>
              <label className="text-sm font-semibold">City</label>
              <input className="input mt-1" name="city" defaultValue={addr?.city ?? ""} placeholder="City" />
            </div>
            <div>
              <label className="text-sm font-semibold">State</label>
              <input className="input mt-1" name="state" defaultValue={addr?.state ?? ""} placeholder="State" />
            </div>
            <div>
              <label className="text-sm font-semibold">Pincode</label>
              <input className="input mt-1" name="pincode" defaultValue={addr?.pincode ?? ""} placeholder="Pincode" />
            </div>
          </div>
        </div>

        <button className="btn-primary w-full" type="submit">Save Profile</button>
      </form>
    </div>
  );
}
