import Link from "next/link";
import { getSession } from "@/lib/auth";

export default async function RefundPage({ searchParams }: { searchParams: { orderId?: string } }) {
  const session = await getSession();
  if (!session) return <div className="card p-6 text-sm text-ink-600">Please <Link className="link" href="/auth">login</Link>.</div>;
  const orderId = searchParams.orderId ?? "";
  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Refund Request</div>
        <div className="text-sm text-ink-600">Photo is mandatory; video optional. Admin approves in 24–48h.</div>
      </div>

      <form className="card p-5 space-y-4" action="/api/refunds/create" method="post" encType="multipart/form-data">
        <input type="hidden" name="orderId" value={orderId} />
        <div>
          <label className="text-sm font-semibold">Reason</label>
          <textarea className="input mt-1 h-24" name="reason" required placeholder="Explain the issue..." />
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <label className="text-sm font-semibold">Photo (required)</label>
            <input className="input mt-1" type="file" name="photo" accept="image/*" required />
          </div>
          <div>
            <label className="text-sm font-semibold">Video (optional)</label>
            <input className="input mt-1" type="file" name="video" accept="video/*" />
          </div>
        </div>
        <button className="btn-primary w-full" type="submit">Submit Refund Request</button>
      </form>
    </div>
  );
}
