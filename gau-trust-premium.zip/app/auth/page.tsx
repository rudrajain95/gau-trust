import { prisma } from "@/lib/prisma";
import { Shell } from "@/components/Shell";
import Link from "next/link";

export default async function AuthPage() {
  const demoUsers = await prisma.user.findMany({
    orderBy: { role: "asc" },
    take: 10,
    select: { id: true, role: true, phone: true, name: true },
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-ink-100 via-ink-50 to-brand-100">
      <div className="container-pad py-10">
        <div className="mx-auto max-w-xl card p-6">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-2xl bg-brand-600 text-white grid place-items-center font-black text-lg">G</div>
            <div>
              <div className="text-xl font-black tracking-tight">Sign in to Gau Trust</div>
              <div className="text-sm text-ink-600">OTP login (dev mock OTP: <span className="font-bold">123456</span>)</div>
            </div>
          </div>

          <form className="mt-6 space-y-3" action="/api/auth/request-otp" method="post">
            <div>
              <label className="text-sm font-semibold">Phone Number</label>
              <input name="phone" className="input mt-1" placeholder="+91 9xxxxxxxxx" required />
            </div>
            <button className="btn-primary w-full" type="submit">Send OTP</button>
          </form>

          <form className="mt-4 space-y-3" action="/api/auth/verify-otp" method="post">
            <div>
              <label className="text-sm font-semibold">OTP</label>
              <input name="otp" className="input mt-1" placeholder="123456" required />
            </div>
            <button className="btn-primary w-full" type="submit">Verify & Login</button>
          </form>

          <div className="mt-6 border-t border-ink-200 pt-4">
            <div className="text-sm font-bold">Demo Accounts (1-click)</div>
            <div className="mt-2 grid gap-2">
              {demoUsers.map(u => (
                <form key={u.id} action="/api/auth/demo-login" method="post" className="flex items-center justify-between rounded-xl border border-ink-200 bg-ink-50 px-3 py-2">
                  <input type="hidden" name="userId" value={u.id} />
                  <div className="text-sm">
                    <div className="font-semibold">{u.role}</div>
                    <div className="text-xs text-ink-600">{u.name ?? "Demo User"} • {u.phone}</div>
                  </div>
                  <button className="btn-primary" type="submit">Login</button>
                </form>
              ))}
            </div>
            <div className="mt-3 text-xs text-ink-600">
              Optional Google login is a placeholder in this build.
            </div>
          </div>

          <div className="mt-6 text-center text-xs text-ink-500">
            By continuing you agree to basic terms for demo use.
          </div>
        </div>

        <div className="mt-6 text-center text-xs">
          <Link className="link" href="/customer">Continue as Guest (limited)</Link>
        </div>
      </div>
    </div>
  );
}
