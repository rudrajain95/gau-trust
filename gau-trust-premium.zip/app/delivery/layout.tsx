import { Shell } from "@/components/Shell";
import { getSession } from "@/lib/auth";

export default async function DeliveryLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  return (
    <Shell
      title="Gau Trust"
      subtitle="Delivery"
      user={session?.user ? { name: session.user.name, phone: session.user.phone, role: session.user.role } : undefined}
      nav={[
        { href: "/delivery", label: "Assigned" },
      ]}
    >
      {children}
    </Shell>
  );
}
