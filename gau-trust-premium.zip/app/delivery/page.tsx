import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function DeliveryHome() {
  const auth = await requireRole(["DELIVERY"]);
  if (!auth.ok) return <div className="card p-6">Delivery only. Login with DELIVERY demo.</div>;

  const orders = await prisma.order.findMany({
    where: { status: { in: ["OUT_FOR_DELIVERY", "PACKED", "ACCEPTED"] } },
    orderBy: { createdAt: "desc" },
    take: 20,
    include: { user: true, shop: true },
  });

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="text-lg font-black tracking-tight">Assigned Deliveries (Demo)</div>
        <div className="text-sm text-ink-600">Update location + mark delivered with OTP/photo proof later.</div>
      </div>

      <div className="grid gap-3">
        {orders.map(o => (
          <form key={o.id} className="card p-5 space-y-3" action="/api/delivery/update-location" method="post">
            <input type="hidden" name="orderId" value={o.id} />
            <div className="flex items-start justify-between">
              <div>
                <div className="font-black">#{o.id.slice(-6)} • {o.user.phone}</div>
                <div className="text-xs text-ink-500">{o.shop.name} • Total ₹{o.total} • Status {o.status}</div>
              </div>
              <button className="btn-primary" type="submit">Add Location Event</button>
            </div>
            <div className="text-xs text-ink-500">This demo adds a random location point; integrate real browser geolocation in next iteration.</div>
          </form>
        ))}
      </div>
    </div>
  );
}
