import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { computeCoins, deliveryFeeByDistance, getSettings, nonSubSchedule, isWithinSubscriberFreeWindow } from "@/lib/rules";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.redirect(new URL("/auth", req.url), 303);

  const c = await cookies();
  const raw = c.get("gt_cart")?.value;
  if (!raw) return NextResponse.redirect(new URL("/customer/marketplace?err=cart", req.url), 303);

  const cart = JSON.parse(decodeURIComponent(raw)) as { shopId: string; items: { productId: string; qty: number }[] };

  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (!user) return NextResponse.redirect(new URL("/auth?err=user", req.url), 303);

  const settings = await getSettings();

  // Demo distance using random 1-5km (in real: compute from geolocation + shop coords)
  const distanceKm = Math.round((1 + Math.random() * 5) * 10) / 10;

  const isSubscriber = user.role === "SUBSCRIBER" || (user.subscriptionEndsAt ? user.subscriptionEndsAt > new Date() : false);
  const trialActive = user.trialEndsAt ? user.trialEndsAt > new Date() : false;

  let deliveryFee = 0;
  let serviceable = true;

  if (isSubscriber) {
    deliveryFee = isWithinSubscriberFreeWindow(new Date()) ? 0 : 0; // still free in this demo
  } else if (trialActive) {
    deliveryFee = 0;
  } else {
    const r = deliveryFeeByDistance(distanceKm, settings.deliveryFee0to3, settings.deliveryFee3to6);
    deliveryFee = r.fee;
    serviceable = r.serviceable;
  }

  if (!serviceable) {
    return NextResponse.redirect(new URL("/customer/marketplace?err=distance", req.url), 303);
  }

  const products = await prisma.product.findMany({ where: { id: { in: cart.items.map(i => i.productId) } } });
  const items = cart.items.map(i => {
    const p = products.find(pp => pp.id === i.productId)!;
    return { productId: p.id, qty: i.qty, unitPrice: p.price, lineTotal: p.price * i.qty };
  });

  const subtotal = items.reduce((a,b)=>a+b.lineTotal,0);
  const total = subtotal + deliveryFee;

  const schedule = isSubscriber ? { scheduledFor: new Date() } : nonSubSchedule(new Date());

  const order = await prisma.order.create({
    data: {
      userId: user.id,
      shopId: cart.shopId,
      subtotal,
      deliveryFee,
      total,
      distanceKm,
      scheduledFor: schedule.scheduledFor,
      items: { create: items },
      tracking: { create: [{ type: "ORDER_PLACED", actorId: user.id, actorRole: user.role, meta: { distanceKm, schedule } }] },
      payments: {
        create: [{
          method: "UPI",
          status: "PAID",
          amount: total,
          meta: { demo: true }
        }]
      }
    }
  });

  // Coins for subscribers only
  if (isSubscriber) {
    const coins = computeCoins(total);
    if (coins > 0) {
      await prisma.coinTransaction.create({ data: { userId: user.id, orderId: order.id, amount: coins, type: "EARNED", meta: { total } } });
      await prisma.user.update({ where: { id: user.id }, data: { coinBalance: { increment: coins } } });
    }
  }

  c.delete("gt_cart");
  return NextResponse.redirect(new URL(`/customer/orders/${order.id}`, req.url), 303);
}
