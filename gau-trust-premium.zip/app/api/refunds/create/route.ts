import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { nanoid } from "nanoid";
import fs from "fs/promises";
import path from "path";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.redirect(new URL("/auth", req.url), 303);

  const formData = await req.formData();
  const orderId = String(formData.get("orderId") ?? "");
  const reason = String(formData.get("reason") ?? "");

  const photo = formData.get("photo") as File | null;
  const video = formData.get("video") as File | null;

  if (!orderId || !photo) return NextResponse.redirect(new URL("/customer/orders?err=refund", req.url), 303);

  const uploadsDir = path.join(process.cwd(), "uploads");
  await fs.mkdir(uploadsDir, { recursive: true });

  async function saveFile(file: File, kind: string) {
    const buf = Buffer.from(await file.arrayBuffer());
    const ext = file.name.includes(".") ? file.name.split(".").pop() : "bin";
    const filename = `${kind}_${nanoid(10)}.${ext}`;
    const filepath = path.join(uploadsDir, filename);
    await fs.writeFile(filepath, buf);
    const up = await prisma.upload.create({
      data: { kind, path: `uploads/${filename}`, mime: file.type, size: buf.length, ownerId: session.user.id },
    });
    return up;
  }

  const photoUp = await saveFile(photo, "refund_photo");
  const videoUp = video && video.size ? await saveFile(video, "refund_video") : null;

  await prisma.refundRequest.create({
    data: {
      orderId,
      userId: session.user.id,
      reason,
      photoUploadId: photoUp.id,
      videoUploadId: videoUp?.id,
    },
  });

  return NextResponse.redirect(new URL(`/customer/orders/${orderId}?refund=submitted`, req.url), 303);
}
