import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.redirect(new URL("/auth", req.url), 303);

  const now = new Date();
  const ends = new Date(now);
  ends.setMonth(ends.getMonth() + 1);

  await prisma.user.update({
    where: { id: session.user.id },
    data: { role: "SUBSCRIBER", subscriptionEndsAt: ends },
  });

  return NextResponse.redirect(new URL("/customer/wallet?sub=ok", req.url), 303);
}
