import { NextResponse } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const auth = await requireRole(["SHOP_OWNER"]);
  if (!auth.ok) return NextResponse.redirect(new URL("/shop", req.url), 303);

  const form = await req.formData();
  const productId = String(form.get("productId") ?? "");
  const price = Number(form.get("price") ?? 0);
  const stock = Number(form.get("stock") ?? 0);

  await prisma.product.update({ where: { id: productId }, data: { price, stock } });
  return NextResponse.redirect(new URL("/shop/products?saved=1", req.url), 303);
}
