import { NextResponse } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const auth = await requireRole(["SHOP_OWNER"]);
  if (!auth.ok) return NextResponse.redirect(new URL("/shop", req.url), 303);

  const form = await req.formData();
  const orderId = String(form.get("orderId") ?? "");
  const status = String(form.get("status") ?? "ACCEPTED");

  await prisma.order.update({
    where: { id: orderId },
    data: { status: status as any, tracking: { create: [{ type: `SHOP_${status}`, actorId: auth.session!.user.id, actorRole: "SHOP_OWNER" }] } },
  });

  return NextResponse.redirect(new URL("/shop/orders?saved=1", req.url), 303);
}
