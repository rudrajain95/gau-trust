import { NextResponse } from "next/server";
import { cookies } from "next/headers";

type CartItem = { productId: string; qty: number };
type Cart = { shopId: string; items: CartItem[] };

export async function POST(req: Request) {
  const form = await req.formData();
  const productId = String(form.get("productId") ?? "");
  const shopId = String(form.get("shopId") ?? "");
  const qty = Math.max(1, Number(form.get("qty") ?? 1));

  const c = await cookies();
  const raw = c.get("gt_cart")?.value;
  const cart: Cart = raw ? JSON.parse(decodeURIComponent(raw)) : { shopId, items: [] };
  if (cart.shopId !== shopId) {
    cart.shopId = shopId;
    cart.items = [];
  }
  const existing = cart.items.find(i => i.productId === productId);
  if (existing) existing.qty += qty;
  else cart.items.push({ productId, qty });

  c.set("gt_cart", encodeURIComponent(JSON.stringify(cart)), { httpOnly: false, sameSite: "lax", path: "/" });
  return NextResponse.redirect(new URL(`/customer/marketplace/shop/${shopId}`, req.url), 303);
}
