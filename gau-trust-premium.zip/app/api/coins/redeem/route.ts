import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.redirect(new URL("/auth", req.url), 303);

  const form = await req.formData();
  const reward = String(form.get("reward") ?? "₹200 Voucher");

  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (!user) return NextResponse.redirect(new URL("/auth", req.url), 303);
  if (user.role !== "SUBSCRIBER") return NextResponse.redirect(new URL("/customer/wallet?err=sub", req.url), 303);
  if (user.coinBalance < 500) return NextResponse.redirect(new URL("/customer/wallet?err=coins", req.url), 303);

  await prisma.$transaction([
    prisma.user.update({ where: { id: user.id }, data: { coinBalance: { decrement: 500 } } }),
    prisma.redemption.create({ data: { userId: user.id, reward, coinsUsed: 500 } }),
    prisma.coinTransaction.create({ data: { userId: user.id, amount: -500, type: "REDEEM", meta: { reward } } }),
  ]);

  return NextResponse.redirect(new URL("/customer/wallet?redeem=ok", req.url), 303);
}
