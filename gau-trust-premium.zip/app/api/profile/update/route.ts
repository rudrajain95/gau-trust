import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.redirect(new URL("/auth", req.url), 303);

  const form = await req.formData();
  const name = String(form.get("name") ?? "").trim() || null;
  const email = String(form.get("email") ?? "").trim() || null;
  const notes = String(form.get("notes") ?? "").trim() || null;

  const line1 = String(form.get("line1") ?? "").trim();
  const line2 = String(form.get("line2") ?? "").trim() || null;
  const city = String(form.get("city") ?? "").trim();
  const state = String(form.get("state") ?? "").trim();
  const pincode = String(form.get("pincode") ?? "").trim();

  await prisma.user.update({ where: { id: session.user.id }, data: { name, email, notes } });

  // Upsert one primary address if any address field is provided
  if (line1 || city || state || pincode) {
    const existing = await prisma.address.findFirst({ where: { userId: session.user.id } });
    if (existing) {
      await prisma.address.update({
        where: { id: existing.id },
        data: { line1, line2, city, state, pincode },
      });
    } else {
      await prisma.address.create({
        data: { userId: session.user.id, line1, line2, city: city || "Chhatarpur", state: state || "MP", pincode: pincode || "000000" },
      });
    }
  }

  return NextResponse.redirect(new URL("/customer/profile?saved=1", req.url), 303);
}
