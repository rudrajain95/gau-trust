import { NextResponse } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const auth = await requireRole(["DELIVERY"]);
  if (!auth.ok) return NextResponse.redirect(new URL("/delivery", req.url), 303);

  const form = await req.formData();
  const orderId = String(form.get("orderId") ?? "");

  const latitude = 24.9 + Math.random() * 0.2; // demo around MP-ish
  const longitude = 79.5 + Math.random() * 0.2;

  await prisma.trackingEvent.create({
    data: {
      orderId,
      actorId: auth.session!.user.id,
      actorRole: "DELIVERY",
      type: "LOCATION_PING",
      latitude,
      longitude,
    },
  });

  return NextResponse.redirect(new URL(`/customer/orders/${orderId}`, req.url), 303);
}
