import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSession } from "@/lib/auth";

export async function POST(req: Request) {
  const form = await req.formData();
  const otp = String(form.get("otp") ?? "").trim();
  const pendingPhone = req.headers.get("cookie")?.match(/gt_pending_phone=([^;]+)/)?.[1];
  const phone = decodeURIComponent(pendingPhone ?? "").trim();

  if (!phone) return NextResponse.redirect(new URL("/auth", req.url), 303);

  // Dev mock OTP
  if (otp !== "123456") {
    return NextResponse.redirect(new URL("/auth?err=otp", req.url), 303);
  }

  const user = await prisma.user.upsert({
    where: { phone },
    update: {},
    create: {
      phone,
      role: "CUSTOMER",
      trialEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    },
  });

  await createSession(user.id);

  const res = NextResponse.redirect(new URL("/", req.url), 303);
  res.cookies.delete("gt_pending_phone");
  return res;
}
