import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSession } from "@/lib/auth";

export async function POST(req: Request) {
  const form = await req.formData();
  const userId = String(form.get("userId") ?? "");
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return NextResponse.redirect(new URL("/auth?err=user", req.url), 303);
  await createSession(user.id);
  return NextResponse.redirect(new URL("/", req.url), 303);
}
