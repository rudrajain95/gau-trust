import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const form = await req.formData();
  const phone = String(form.get("phone") ?? "").trim();
  // In production: send OTP via SMS provider. In dev: show mock OTP.
  const res = NextResponse.redirect(new URL("/auth", req.url), 303);
  res.cookies.set("gt_pending_phone", phone, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 10 * 60 });
  return res;
}
