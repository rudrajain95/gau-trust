import { NextResponse } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const auth = await requireRole(["ADMIN"]);
  if (!auth.ok) return NextResponse.redirect(new URL("/admin", req.url), 303);

  const form = await req.formData();
  const refundId = String(form.get("refundId") ?? "");
  const status = String(form.get("status") ?? "PENDING");
  const adminNote = String(form.get("adminNote") ?? "").trim() || null;

  const refund = await prisma.refundRequest.update({
    where: { id: refundId },
    data: { status, adminNote },
    include: { order: true, user: true },
  });

  // If approved, mark order refunded and reverse coins (if any)
  if (status === "APPROVED") {
    await prisma.order.update({ where: { id: refund.orderId }, data: { status: "REFUNDED" } });

    const coinEarn = await prisma.coinTransaction.findFirst({ where: { orderId: refund.orderId, type: "EARNED" } });
    if (coinEarn) {
      await prisma.$transaction([
        prisma.coinTransaction.create({ data: { userId: refund.userId, orderId: refund.orderId, amount: -coinEarn.amount, type: "REVERSAL", meta: { reason: "Refund approved" } } }),
        prisma.user.update({ where: { id: refund.userId }, data: { coinBalance: { decrement: coinEarn.amount } } }),
      ]);
    }
  }

  return NextResponse.redirect(new URL("/admin/refunds?ok=1", req.url), 303);
}
