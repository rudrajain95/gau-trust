import { NextResponse } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const auth = await requireRole(["ADMIN"]);
  if (!auth.ok) return NextResponse.redirect(new URL("/admin", req.url), 303);

  const form = await req.formData();
  const shopId = String(form.get("shopId") ?? "");
  const commissionPercent = Number(form.get("commissionPercent") ?? 8);
  const approved = String(form.get("approved") ?? "false") === "true";

  await prisma.shop.update({
    where: { id: shopId },
    data: { commissionPercent, approved },
  });

  return NextResponse.redirect(new URL("/admin/shops?saved=1", req.url), 303);
}
