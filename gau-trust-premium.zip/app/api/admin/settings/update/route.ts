import { NextResponse } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const auth = await requireRole(["ADMIN"]);
  if (!auth.ok) return NextResponse.redirect(new URL("/admin", req.url), 303);

  const form = await req.formData();
  const deliveryFee0to3 = Number(form.get("deliveryFee0to3") ?? 5);
  const deliveryFee3to6 = Number(form.get("deliveryFee3to6") ?? 10);
  const subscriptionPrice = Number(form.get("subscriptionPrice") ?? 199);
  const supportContact = String(form.get("supportContact") ?? "+91-00000-00000");

  await prisma.settings.upsert({
    where: { id: "singleton" },
    update: { deliveryFee0to3, deliveryFee3to6, subscriptionPrice, supportContact },
    create: { id: "singleton", deliveryFee0to3, deliveryFee3to6, subscriptionPrice, supportContact },
  });

  return NextResponse.redirect(new URL("/admin/settings?saved=1", req.url), 303);
}
