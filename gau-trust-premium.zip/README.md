# Gau Trust Premium (Next.js + Prisma + Postgres)

This is a production-grade starter for **Gau Trust** (dairy marketplace + subscription) with:
- Next.js App Router (Customer PWA + portals)
- Prisma + PostgreSQL
- OTP login (dev mock OTP **123456**) + demo role accounts
- Premium UI theme: **light gray base + sky-blue accents**
- Working Profile page (name/email/mobile/address edit + persist)
- Seeded dairy marketplace products (milk, paneer, bread, butter, buttermilk, khowa, curd)
- Refund request flow (photo required) with local uploads (dev)
- Admin shops approvals + settings (support contact, delivery fees)
- Delivery portal with demo location tracking events

## Quick Start

### 1) Install
```bash
npm install
```

### 2) Start Postgres (recommended via Docker)
```bash
docker compose up -d
```

### 3) Configure env
Copy `.env.example` to `.env` and keep DATABASE_URL.

### 4) Migrate + Seed
```bash
npm run db:migrate
npm run db:seed
```

### 5) Run
```bash
npm run dev
```

Open:
- `/auth` to login (OTP or demo accounts)

## Demo Accounts
On `/auth` you can 1-click login as:
- CUSTOMER (trial)
- SUBSCRIBER
- SHOP_OWNER
- DELIVERY
- ADMIN

## Business Rules Implemented (Demo)
- New customers get 7-day FREE delivery trial (trialEndsAt)
- Subscription ₹199/month (Wallet page)
- Delivery fee for non-subs is distance-based (demo uses random distance 1–6km)
- Subscribers earn coins per order and can redeem at 500 coins
- Refund approvals reverse earned coins for that order

## Notes for Real Launch
- Replace OTP mock with SMS provider (Msg91/Twilio/etc.)
- Replace local uploads with S3 (already isolated in Upload model)
- Replace demo distance with real distance between customer and shop coordinates
- Add COD 50% advance logic + payment gateway integration

