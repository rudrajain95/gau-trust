import { prisma } from "../lib/prisma";

async function main() {
  await prisma.settings.upsert({
    where: { id: "singleton" },
    update: {},
    create: {
      id: "singleton",
      supportContact: "+91-99999-88888",
      deliveryFee0to3: 5,
      deliveryFee3to6: 10,
      subscriptionPrice: 199,
    },
  });

  // Demo users
  const users = await Promise.all([
    prisma.user.upsert({
      where: { phone: "+91-70000-00001" },
      update: {},
      create: { phone: "+91-70000-00001", role: "CUSTOMER", name: "Trial Customer", trialEndsAt: new Date(Date.now() + 7*24*60*60*1000) },
    }),
    prisma.user.upsert({
      where: { phone: "+91-70000-00002" },
      update: {},
      create: { phone: "+91-70000-00002", role: "SUBSCRIBER", name: "Subscriber User", subscriptionEndsAt: new Date(Date.now() + 30*24*60*60*1000), coinBalance: 120 },
    }),
    prisma.user.upsert({
      where: { phone: "+91-70000-00003" },
      update: {},
      create: { phone: "+91-70000-00003", role: "SHOP_OWNER", name: "Shop Owner" },
    }),
    prisma.user.upsert({
      where: { phone: "+91-70000-00004" },
      update: {},
      create: { phone: "+91-70000-00004", role: "DELIVERY", name: "Delivery Agent" },
    }),
    prisma.user.upsert({
      where: { phone: "+91-70000-00005" },
      update: {},
      create: { phone: "+91-70000-00005", role: "ADMIN", name: "Admin" },
    }),
  ]);

  const shopOwner = users[2];
  const shop = await prisma.shop.upsert({
    where: { id: "demo-shop" },
    update: {},
    create: {
      id: "demo-shop",
      name: "Gau Trust Partner Dairy",
      ownerId: shopOwner.id,
      approved: true,
      commissionPercent: 8,
      address: "Chhatarpur, MP",
      latitude: 24.91,
      longitude: 79.59,
    },
  });

  const products = [
    { name: "Fresh Cow Milk", category: "Milk", variant: "500ml", price: 30, stock: 200 },
    { name: "Fresh Cow Milk", category: "Milk", variant: "1L", price: 60, stock: 150 },
    { name: "Paneer", category: "Paneer", variant: "200g", price: 90, stock: 60, packaged: true },
    { name: "Curd", category: "Curd", variant: "500g", price: 45, stock: 80, packaged: true },
    { name: "Buttermilk", category: "Buttermilk", variant: "500ml", price: 25, stock: 90, packaged: true },
    { name: "Butter", category: "Butter", variant: "100g", price: 55, stock: 50, packaged: true },
    { name: "Bread", category: "Bread", variant: "400g", price: 40, stock: 70, packaged: true },
    { name: "Khowa", category: "Khowa", variant: "250g", price: 120, stock: 30, packaged: true },
    { name: "Ghee", category: "Ghee", variant: "500ml", price: 320, stock: 20, packaged: true },
  ];

  for (const p of products) {
    await prisma.product.upsert({
      where: { id: `${shop.id}-${p.name}-${p.variant}`.replace(/\s+/g, "-").toLowerCase() },
      update: { price: p.price, stock: p.stock, active: true },
      create: {
        id: `${shop.id}-${p.name}-${p.variant}`.replace(/\s+/g, "-").toLowerCase(),
        shopId: shop.id,
        name: p.name,
        category: p.category,
        variant: p.variant,
        price: p.price,
        stock: p.stock,
        packaged: Boolean((p as any).packaged),
      },
    });
  }

  await prisma.deliveryAgent.upsert({
    where: { userId: users[3].id },
    update: {},
    create: { userId: users[3].id },
  });

  console.log("Seed complete.");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
