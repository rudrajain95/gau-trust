import { prisma } from "@/lib/prisma";

export function computeCoins(totalRupees: number) {
  if (totalRupees >= 500) return 50;
  if (totalRupees >= 400) return 30;
  if (totalRupees >= 300) return 20;
  if (totalRupees >= 200) return 10;
  if (totalRupees >= 100) return 5;
  if (totalRupees >= 50) return 1;
  return 0;
}

export function deliveryFeeByDistance(distanceKm: number, fee0to3: number, fee3to6: number) {
  if (distanceKm <= 3) return { fee: fee0to3, serviceable: true };
  if (distanceKm <= 6) return { fee: fee3to6, serviceable: true };
  return { fee: 0, serviceable: false };
}

export function isWithinSubscriberFreeWindow(date: Date) {
  const h = date.getHours();
  return h >= 6 && h < 21; // 6AM–9PM
}

export function nonSubSchedule(now: Date) {
  const noon = new Date(now);
  noon.setHours(12, 0, 0, 0);
  if (now <= noon) {
    const sameDay = new Date(now);
    sameDay.setHours(6, 0, 0, 0);
    return { type: "SAME_DAY_MORNING" as const, scheduledFor: sameDay };
  }
  const nextDay = new Date(now);
  nextDay.setDate(nextDay.getDate() + 1);
  nextDay.setHours(6, 0, 0, 0);
  return { type: "NEXT_DAY_MORNING" as const, scheduledFor: nextDay };
}

export async function getSettings() {
  const s = await prisma.settings.upsert({
    where: { id: "singleton" },
    update: {},
    create: { id: "singleton" },
  });
  return s;
}
