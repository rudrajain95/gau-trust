import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { Role } from "@prisma/client";

const COOKIE_NAME = "gt_session";
const SESSION_TTL_DAYS = 30;

export type SessionUser = {
  id: string;
  role: Role;
  phone: string;
  name: string | null;
  email: string | null;
};

export async function getSession() {
  const token = (await cookies()).get(COOKIE_NAME)?.value;
  if (!token) return null;

  const tokenHash = await bcrypt.hash(token, 8); // not used directly
  // We can't recompute bcrypt deterministically; store plain token hashed with bcrypt at creation and compare with bcrypt.compare
  const sessions = await prisma.session.findMany({
    where: { expiresAt: { gt: new Date() } },
    include: { user: true },
  });
  for (const s of sessions) {
    const ok = await bcrypt.compare(token, s.tokenHash);
    if (ok) {
      return {
        sessionId: s.id,
        user: {
          id: s.user.id,
          role: s.user.role,
          phone: s.user.phone,
          name: s.user.name,
          email: s.user.email,
        } satisfies SessionUser,
      };
    }
  }
  return null;
}

export async function requireRole(roles: Role[]) {
  const session = await getSession();
  if (!session) return { ok: false as const, session: null };
  if (!roles.includes(session.user.role)) return { ok: false as const, session };
  return { ok: true as const, session };
}

export async function createSession(userId: string) {
  const token = cryptoRandomToken();
  const tokenHash = await bcrypt.hash(token, 10);
  const expiresAt = new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);

  await prisma.session.create({
    data: { userId, tokenHash, expiresAt },
  });

  (await cookies()).set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
}

export async function clearSession() {
  (await cookies()).delete(COOKIE_NAME);
}

function cryptoRandomToken() {
  // Use Web Crypto when available (Next runtime)
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return Buffer.from(bytes).toString("base64url");
}
